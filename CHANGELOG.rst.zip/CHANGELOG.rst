5.0.1 2015-03-08

- Bug fixed in Exception on unnamed exports -> https://github.com/guelfoweb/peframe/issues/12

5.0 - 2016-02-10

- Added check for mutex object

5.0beta - 2015-11-12

- Added check for virus total
- Added configurable json file in signatures folder
- Added parsing resource directory
- Bug fixed in section name with unicode chars
- Rewrited code structure

4.2 - 2015-01-08

- Added check for XOR Obfuscation

4.1 - 2014-08-28

- Added check for Digital Signature
- Removed database SQlite
- Fixed output JSON
- Rewrited code structure

4.0 - 2014-06-10

- Added SQlite database to store report by auto analysis
- Added Json output only for auto analysis
- Bug fixed in --export option -> https://github.com/guelfoweb/peframe/issues/2

3.0 rc3 - 2014-05-14

- Calculate the "import hash" of embedded/dropped executables -> https://www.mandiant.com/blog/tracking-malware-import-hashing/

3.0 rc2 - 2014-03-14

- Assigns file type to the names of the files found

3.0 rc1 - 2014-03-13

- Rewrite code and options

1.x - 2.0

- old version on Google Code -> http://code.google.com/p/peframe/
